-- =============================================================================
-- Layout: Adiantamento
-- Staging : Arquivo_Adiantamento_Tratado
-- Destino : FichaRazao_MG
-- Procedure: up_01_Extrai_Adiantamento_gx (@BancoDadosGX, @BancoWF)
-- Depende : Pessoa_MG (CPF_CNPJ), Empresa_DePara (CNPJ_EMPRESA)
-- =============================================================================

USE [DadosGX_SeuProjeto];  -- ALTERE para o nome real do banco DadosGX
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE NAME = 'up_01_Extrai_Adiantamento_gx' AND TYPE = 'P')
    DROP PROCEDURE dbo.up_01_Extrai_Adiantamento_gx;
GO

CREATE PROCEDURE dbo.up_01_Extrai_Adiantamento_gx
    @BancoDadosGX VARCHAR(MAX),
    @BancoWF      VARCHAR(MAX)
AS
DECLARE @CMD NVARCHAR(MAX)

IF NOT EXISTS (SELECT 1 FROM MASTER.DBO.SYSDATABASES WHERE NAME = @BancoDadosGX)
BEGIN
    PRINT 'O < ' + @BancoDadosGX + ' > INFORMADO NAO EXISTE NESTE SERVIDOR!'
    RETURN
END

SELECT @CMD = N'
    IF NOT EXISTS (
        SELECT 1 FROM ' + QUOTENAME(LTRIM(RTRIM(@BancoDadosGX))) + N'.sys.objects
        WHERE type = ''U'' AND name = ''Arquivo_Adiantamento_Tratado''
    )
        SELECT @ok = 0
    ELSE
        SELECT @ok = 1
'
DECLARE @StagingOk BIT = 0
EXEC sp_executesql @CMD, N'@ok BIT OUTPUT', @ok = @StagingOk OUTPUT
IF @StagingOk = 0
BEGIN
    PRINT 'O < ARQUIVO > INFORMADO NAO EXISTE NESTE BANCO ' + @BancoDadosGX + '!'
    RETURN
END

PRINT '=========================================================================================='
PRINT ' Extrai_Adiantamento - Atualiza CPFCNPJ e TIPO_MOVFINANCEIRO'
PRINT '=========================================================================================='

SELECT @CMD = N'
    UPDATE ' + QUOTENAME(LTRIM(RTRIM(@BancoDadosGX))) + N'.dbo.Arquivo_Adiantamento_Tratado SET
        CPF_CNPJ = RTRIM(LTRIM(dbo.FN_RemoveCaracteresNaoInteiros(CPF_CNPJ))),
        TIPO_MOVFINANCEIRO = UPPER(RTRIM(LTRIM(TIPO_MOVFINANCEIRO)))
'
EXEC sp_executesql @CMD

PRINT '=========================================================================================='
PRINT ' Cria a cópia do Arquivo_Adiantamento_Tratado para Migração'
PRINT '=========================================================================================='

SELECT @CMD = N'
    IF ( NOT EXISTS (SELECT 1 FROM ' + QUOTENAME(LTRIM(RTRIM(@BancoDadosGX))) + N'.sys.objects WHERE type = ''U'' AND name =''FichaRazao_MG'') )
    BEGIN
        SELECT a.* INTO ' + QUOTENAME(LTRIM(RTRIM(@BancoDadosGX))) + N'.dbo.FichaRazao_MG
        FROM ' + QUOTENAME(LTRIM(RTRIM(@BancoDadosGX))) + N'.dbo.Arquivo_Adiantamento_Tratado a
        WHERE 1 = 1
    END
'
EXEC sp_executesql @CMD

SELECT @CMD = '
    IF ( NOT EXISTS (SELECT 1 FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.columns col INNER JOIN ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.objects obj ON col.object_id = obj.object_id WHERE col.name = ''Empresa_Codigo'' AND obj.name = ''FichaRazao_MG''))
        ALTER TABLE ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG ADD Empresa_Codigo int NULL
    IF ( NOT EXISTS (SELECT 1 FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.columns col INNER JOIN ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.objects obj ON col.object_id = obj.object_id WHERE col.name = ''Pessoa_DocIdentificador'' AND obj.name = ''FichaRazao_MG''))
        ALTER TABLE ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG ADD Pessoa_DocIdentificador varchar(20) NULL
    IF ( NOT EXISTS (SELECT 1 FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.columns col INNER JOIN ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.objects obj ON col.object_id = obj.object_id WHERE col.name = ''Pessoa_Codigo'' AND obj.name = ''FichaRazao_MG''))
        ALTER TABLE ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG ADD Pessoa_Codigo int NULL
    IF ( NOT EXISTS (SELECT 1 FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.columns col INNER JOIN ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.objects obj ON col.object_id = obj.object_id WHERE col.name = ''TipoFichaRazao_CodigoWF'' AND obj.name = ''FichaRazao_MG''))
        ALTER TABLE ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG ADD TipoFichaRazao_CodigoWF int NULL
    IF ( NOT EXISTS (SELECT 1 FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.columns col INNER JOIN ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.objects obj ON col.object_id = obj.object_id WHERE col.name = ''Ocorrencia'' AND obj.name = ''FichaRazao_MG''))
        ALTER TABLE ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG ADD Ocorrencia varchar(500) NULL
    IF ( NOT EXISTS (SELECT 1 FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.columns col INNER JOIN ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.objects obj ON col.object_id = obj.object_id WHERE col.name = ''VALOR_ORIGINAL'' AND obj.name = ''FichaRazao_MG''))
        ALTER TABLE ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG ADD VALOR_ORIGINAL varchar(max) NULL
    IF ( NOT EXISTS (SELECT 1 FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.columns col INNER JOIN ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.objects obj ON col.object_id = obj.object_id WHERE col.name = ''DESCRICAO_FICHARAZAO'' AND obj.name = ''FichaRazao_MG''))
        ALTER TABLE ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG ADD DESCRICAO_FICHARAZAO varchar(max) NULL
'
EXEC sp_executesql @CMD

PRINT '=========================================================================================='
PRINT ' AJUSTE de colunas VALOR com "","" na Tabela FichaRazao_MG'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a
    SET a.VALOR_SALDO = REPLACE(a.VALOR_SALDO,'','',''.''),
        a.VALOR_ORIGINAL = REPLACE(a.VALOR_ORIGINAL,'','',''.'')
    FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Atualiza Flag=0 na Tabela FichaRazao_MG de EMPRESA não existe Empresa_DePara'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a SET a.Ocorrencia = '''' FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a

    UPDATE a
    SET a.Ocorrencia = a.Ocorrencia + '' CNPJ_EMPRESA não existe Empresa_DePara. ''
        ,a.Flag = 0
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    WHERE
        NOT EXISTS(
            SELECT 1
            FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.Empresa_DePara b
            WHERE b.Pessoa_DocIdentificador = a.CNPJ_EMPRESA COLLATE DATABASE_DEFAULT
        )
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Atualiza Flag=0 na Tabela FichaRazao_MG CPF/CNPJ em BRANCO'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a
    SET a.Ocorrencia = CASE
                        WHEN a.CPF_CNPJ IS NULL OR a.CPF_CNPJ = ''''
                        THEN a.Ocorrencia + '' | CPF CNPJ está vazio''
                        ELSE a.Ocorrencia
                    END,
        a.Flag = CASE
                    WHEN a.CPF_CNPJ IS NULL OR a.CPF_CNPJ = '''' THEN 0
                    ELSE a.Flag
                END
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Atualiza Flag=0 na Tabela FichaRazao_MG TIPO_MOVFINANCEIRO inválido'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a
    SET a.Flag = 0
        ,a.Ocorrencia = a.Ocorrencia + '' | TIPO_MOVFINANCEIRO deve ser R ou P.''
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    WHERE
        a.Flag = 1 AND
        ISNULL(a.TIPO_MOVFINANCEIRO, '''') NOT IN (''R'', ''P'')
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Atualiza Flag=0 na Tabela FichaRazao_MG TIPO_FICHARAZAO em BRANCO'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a
    SET a.Flag = 0
        ,a.Ocorrencia = a.Ocorrencia + '' | TIPO_FICHARAZAO está vazio.''
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    WHERE
        a.Flag = 1 AND
        (a.TIPO_FICHARAZAO IS NULL OR RTRIM(LTRIM(a.TIPO_FICHARAZAO)) = '''')
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Atualiza Flag=0 na Tabela FichaRazao_MG VALOR_SALDO = 0 ou inválido'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a
    SET a.Flag = 0
        ,a.Ocorrencia = a.Ocorrencia + '' | VALOR_SALDO = 0 ou inválido.''
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    WHERE
        a.Flag = 1 AND
        (
            TRY_CONVERT(float, a.VALOR_SALDO) IS NULL
            OR TRY_CONVERT(float, a.VALOR_SALDO) = 0
        )
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Atualiza Empresa na tabela FichaRazao_MG'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a
    SET a.Empresa_Codigo = b.Empresa_Codigo
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    INNER JOIN ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.Empresa_DePara b on b.Pessoa_DocIdentificador = a.CNPJ_EMPRESA COLLATE DATABASE_DEFAULT
    WHERE
        a.Flag = 1
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' AJUSTE Pessoa_DocIdentificador na Tabela FichaRazao_MG'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a
    SET a.Pessoa_DocIdentificador = CASE
                                WHEN len(RTRIM(LTRIM(CPF_CNPJ))) < 11
                                    THEN replicate(''0'',11 - len(RTRIM(LTRIM(CPF_CNPJ)))) + RTRIM(LTRIM(CPF_CNPJ))
                                WHEN len(RTRIM(LTRIM(CPF_CNPJ))) > 11 and len(RTRIM(LTRIM(CPF_CNPJ))) < 14
                                    THEN replicate(''0'',14 - len(RTRIM(LTRIM(CPF_CNPJ)))) + RTRIM(LTRIM(CPF_CNPJ))
                                ELSE RTRIM(LTRIM(CPF_CNPJ))
                            END
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    WHERE
        a.Flag = 1
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Atualiza Pessoa na tabela FichaRazao_MG'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a
    SET a.Pessoa_Codigo = b.Pessoa_Codigo
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    INNER JOIN ' + LTRIM(RTRIM(@BancoWF)) + '.dbo.Pessoa b on b.Pessoa_DocIdentificador = a.Pessoa_DocIdentificador COLLATE DATABASE_DEFAULT
    WHERE
        a.Flag = 1
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Consulta Pessoa_DocIdentificador NÃO CADASTRADO'
PRINT '=========================================================================================='

SELECT @CMD = '
    IF(EXISTS(SELECT 1 FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.sys.objects WHERE name = ''Pessoa_Cadastrar'' AND type = ''U''))
    BEGIN
        DROP TABLE ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.Pessoa_Cadastrar
    END

    SELECT DISTINCT
        a.CPF_CNPJ
    INTO ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.Pessoa_Cadastrar
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    WHERE
        a.Flag = 1 AND
        a.Pessoa_Codigo IS NULL

    UPDATE a SET
        a.Ocorrencia = a.Ocorrencia + '' | Cadastrado de Pessoa não encontrado.''
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    WHERE
        a.Flag = 1 AND
        a.Pessoa_Codigo IS NULL
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' Ajusta DATA_MOVIMENTO na Tabela FichaRazao_MG'
PRINT '=========================================================================================='

SELECT @CMD = '
    UPDATE a SET
        a.DATA_MOVIMENTO = REPLACE(a.DATA_MOVIMENTO,''/'',''-'')
    FROM
        ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
    WHERE
        a.Flag = 1
'
EXEC sp_executesql @CMD


PRINT '=========================================================================================='
PRINT ' VERIFICANDO CRITICAS DE EXTRAÇÃO DA TABELA FichaRazao_MG'
PRINT '=========================================================================================='

SELECT @CMD = '
    IF ( SELECT COUNT(*) FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a WHERE a.Ocorrencia != '''' ) > 0
    BEGIN
        PRINT '' ENCONTROU CRITICAS DE EXTRAÇÃO DA TABELA <FichaRazao_MG>''

        SELECT
            ''FichaRazao_MG'' AS [TABELA],
            COUNT(*) AS [QTDE DE REGISTROS FLAG = 0 ]
        FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
        WHERE
            a.Flag = 0

        SELECT
            ''FichaRazao_MG'' AS [TABELA],
            COUNT(*) AS [QTDE DE REGISTROS COM OCORRÊNCIAS]
        FROM ' + LTRIM(RTRIM(@BancoDadosGX)) + '.dbo.FichaRazao_MG a
        WHERE
            a.Ocorrencia != ''''
    END
    ELSE
        PRINT '' NÃO ENCONTROU CRITICAS DE EXTRAÇÃO DA TABELA <FichaRazao_MG>''
'
EXEC sp_executesql @CMD
GO
